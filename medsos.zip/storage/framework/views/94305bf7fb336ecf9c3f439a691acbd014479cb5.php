<?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Twitter Data
      <small>tweet data</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Tables</a></li>
      <li class="active">Data tables</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Twitter Data Sentiments</h3>
            <?php if($kosong): ?>
              <h4><font color="red">Empty Result!</h4></font>
            <?php endif; ?>
          </div>
          <!-- /.box-header -->

          <?php echo e(Form::open(array('url'=>'twitter_data/0'))); ?>

          <div class="col-md-3">
            <div class="form-group">
              <label>Date range:</label>

              <div class="input-group">
                <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
                </div>
                
                <?php echo e(Form::text('date_range','',['class'=>'form-control pull-right','id'=>'reservation'])); ?>

              </div>
              <!-- /.input group -->
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label>Sentiment:</label>
              <?php echo e(Form::select('sentiment',$sentiment_opt,'',['class'=>'form-control select2','style'=>'width:100%','data-placeholder'=>'Select Sentiment'])); ?>

            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label>Keyword:</label>
              <?php echo e(Form::select('keyword',$keyword_opt,'',['class'=>'form-control select2','style'=>'width:100%','data-placeholder'=>'Select Keyword'])); ?>

            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label>&nbsp;</label>
              <?php echo e(Form::submit('Submit',['class'=>'form-control btn btn-info','name'=>'submit'])); ?>

            </div>
          </div>


          <?php echo e(Form::close()); ?>

          <div class="box-body">
            <div class="col-md-2 col-md-offset-8">
              <?php if($offset_prev>=0): ?>
                <a href="<?php echo e(url('twitter_data/'.$offset_prev)); ?>">
                  <button type="button" class="btn btn-block btn-warning">Prev 500</button>
                </a>
              <?php endif; ?>
            </div>

            <div class="col-md-2">
              <a href ="<?php echo e(url('twitter_data/'.$offset_next)); ?>">
                <button type="button" class="btn btn-block btn-info">Next 500</button>
              </a>
            </div>
            <table id="example2" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Keyword</th>
                  <th>Date & Time</th>
                  <th>Timezone</th>
                  <th>Username</th>
                  <th>Tweet</th>
                  <th>Sentiment</th>
                </tr>
              </thead>
              <tbody>
                <?php $no=0;?>
                <?php $__currentLoopData = $tweet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e(++$no); ?></td>
                    <td><?php echo e($value->keyword); ?></td>
                    <td><?php echo e($value->date); ?> | <?php echo e($value->time); ?></td>
                    <td><?php echo e($value->timezone); ?></td>
                    <td><?php echo e($value->username); ?></td>
                    <td><?php echo strlen($value->tweet) >= 140 ?
                    substr($value->tweet, 0, 130) .'<a href="link/to/the/entire/text.htm">[Read more]</a>' :
                    $value->tweet; ?></td>
                    <td>
                      <?php if($value->sentiment == "negatif"): ?>
                        <?php $lbl = "danger"; ?>
                      <?php elseif($value->sentiment == "positif"): ?>
                        <?php $lbl = "success"; ?>
                      <?php elseif($value->sentiment == "netral"): ?>
                        <?php $lbl = "warning"; ?>
                      <?php endif; ?>
                      <button type="button" class="btn btn-block btn-<?php echo e($lbl); ?> btn-xs"><?php echo e($value->sentiment); ?></button>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>

            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->

</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
